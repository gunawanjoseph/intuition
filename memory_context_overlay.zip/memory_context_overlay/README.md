# Memory Context Overlay

A desktop application designed to help users with ADHD or dementia stay focused by providing context about what they were doing. When you get distracted by a notification or lose focus, simply click the overlay icon to instantly recall your recent activity.

## Features

- **Persistent Overlay Icon**: A small, always-visible brain icon (🧠) in the bottom-left corner of your screen
- **Continuous Screen Monitoring**: Captures screen content at ~3 FPS, maintaining a rolling 1-minute context window
- **Smart Text Extraction**: Uses EasyOCR to extract text from screen captures
- **AI-Powered Context Analysis**: Every ~10 seconds, GPT-4.1-mini analyzes screen content to understand what you're doing
- **Key Information Detection**: Automatically detects and stores important information like:
  - OTP/verification codes
  - Email addresses
  - Phone numbers
  - Names
  - URLs/links
  - Prices
  - Order/tracking numbers
- **Info Panel**: Click the icon to see:
  - Activity Summary: "You were doing: [task] using [app]"
  - Key Information: List of detected important items

## Requirements

- **Python**: 3.9 or higher
- **Operating System**: Windows 10/11, macOS 10.15+, or Linux with X11
- **OpenAI API Key**: Required for context analysis
- **Display**: Works best with a single monitor setup

## Installation

### 1. Clone or Download

Download and extract the project files to your preferred location.

### 2. Install Dependencies

```bash
# Using pip
pip install -r requirements.txt

# Or install individually
pip install mss easyocr PyQt6 openai Pillow numpy
```

### 3. Set Up OpenAI API Key

**Windows (PowerShell):**
```powershell
$env:OPENAI_API_KEY = "your-api-key-here"
```

**Windows (Command Prompt):**
```cmd
set OPENAI_API_KEY=your-api-key-here
```

**macOS/Linux:**
```bash
export OPENAI_API_KEY="your-api-key-here"
```

To make it permanent, add the export command to your `~/.bashrc`, `~/.zshrc`, or system environment variables.

## Usage

### Quick Start

**Windows:**
Double-click `run_windows.bat`

**macOS/Linux:**
```bash
./run_unix.sh
# or
python3 run.py
```

### How It Works

1. **Launch**: Start the application using one of the methods above
2. **Look for the Icon**: A 🧠 icon appears in the bottom-left corner of your screen
3. **Continue Working**: The app silently monitors your screen in the background
4. **Get Context**: When you need to remember what you were doing, click the icon
5. **View Info Panel**: See your recent activity and any important information detected

### Info Panel Sections

- **Activity Summary**: Describes what you were doing (e.g., "Writing an email to John about the project deadline")
- **Application**: Shows which app/website you were using (e.g., "Gmail - Chrome")
- **Key Information**: Lists important items with icons:
  - 🔐 OTP/Verification codes
  - 📧 Email addresses
  - 📞 Phone numbers
  - 👤 Names
  - 🔗 URLs/Links
  - 💰 Prices/Amounts
  - 📅 Dates
  - 📦 Order/Tracking numbers

## Configuration

Edit `config.py` to customize the application:

```python
# Screen capture frequency
CAPTURE_FPS = 3.0

# How long to keep history
BUFFER_DURATION = 60  # seconds

# How often to analyze context
ANALYSIS_INTERVAL = 10.0  # seconds

# Icon position
ICON_POSITION = "bottom-left"
```

## Project Structure

```
memory_context_overlay/
├── src/
│   ├── __init__.py          # Package initialization
│   ├── main.py               # Main application entry point
│   ├── screen_capture.py     # Screen capture module
│   ├── ocr_extractor.py      # OCR text extraction
│   ├── context_analyzer.py   # LLM context analysis
│   └── gui_overlay.py        # PyQt6 GUI components
├── assets/                   # (Reserved for icons/images)
├── tests/                    # (Reserved for unit tests)
├── config.py                 # Configuration settings
├── requirements.txt          # Python dependencies
├── run.py                    # Python launcher script
├── run_windows.bat           # Windows launcher
├── run_unix.sh               # macOS/Linux launcher
└── README.md                 # This file
```

## Troubleshooting

### "OPENAI_API_KEY not set"
Make sure you've set the environment variable correctly. The app will still run but won't be able to analyze context.

### Icon not appearing
- Check if another application is using the bottom-left corner
- Try restarting the application
- On Linux, ensure you're running an X11 session (Wayland may have issues)

### OCR is slow
- EasyOCR loads models on first use, which can take 30-60 seconds
- Subsequent extractions are much faster
- Consider reducing `CAPTURE_FPS` in config.py

### High CPU usage
- Reduce `CAPTURE_FPS` to 1.0 or 2.0
- Increase `ANALYSIS_INTERVAL` to 15.0 or 20.0

### Panel shows "Analyzing your activity..."
- Wait for the first analysis cycle (up to 10 seconds)
- Check that your OpenAI API key is valid
- Look at the terminal for error messages

## Privacy & Security

- **Local Processing**: Screen captures are processed locally and never uploaded
- **API Calls**: Only extracted text is sent to OpenAI for analysis
- **No Storage**: Screenshots are not saved to disk (unless debug mode is enabled)
- **Rolling Buffer**: Old data is automatically discarded after 60 seconds

## Known Limitations

- Single monitor support (uses primary monitor)
- English text recognition only (can be extended in config)
- Requires active internet connection for LLM analysis
- May not work well with very fast-changing content (videos, games)

## License

This project is provided as-is for personal use. Feel free to modify and extend it for your needs.

## Support

For issues or feature requests, please create an issue in the project repository.

---

**Remember**: This tool is designed to help, not to replace good focus habits. Use it as a safety net when you get distracted, and consider combining it with other focus techniques like the Pomodoro method.
