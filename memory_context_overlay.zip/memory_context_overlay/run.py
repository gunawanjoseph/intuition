#!/usr/bin/env python3
"""
Memory Context Overlay - Launcher Script
Run this script to start the application.
"""

import sys
import os

# Ensure we're running from the correct directory
script_dir = os.path.dirname(os.path.abspath(__file__))
os.chdir(script_dir)

# Add src to path
sys.path.insert(0, os.path.join(script_dir, 'src'))

# Check for required environment variable
if not os.environ.get('OPENAI_API_KEY'):
    print("=" * 50)
    print("WARNING: OPENAI_API_KEY environment variable not set!")
    print()
    print("The application will run but context analysis will fail.")
    print("Please set your OpenAI API key:")
    print()
    print("  On Windows (PowerShell):")
    print('    $env:OPENAI_API_KEY = "your-api-key-here"')
    print()
    print("  On macOS/Linux:")
    print('    export OPENAI_API_KEY="your-api-key-here"')
    print()
    print("=" * 50)
    print()
    
    response = input("Continue anyway? (y/n): ").strip().lower()
    if response != 'y':
        print("Exiting.")
        sys.exit(0)

# Import and run main application
from main import main

if __name__ == "__main__":
    sys.exit(main())
