# Quick Start Guide

## 5-Minute Setup

### Step 1: Install Python Dependencies

Open a terminal/command prompt and run:

```bash
pip install mss easyocr PyQt6 openai Pillow numpy
```

### Step 2: Set Your OpenAI API Key

**Windows (PowerShell):**
```powershell
$env:OPENAI_API_KEY = "sk-your-key-here"
```

**macOS/Linux:**
```bash
export OPENAI_API_KEY="sk-your-key-here"
```

### Step 3: Run the Application

**Windows:** Double-click `run_windows.bat`

**macOS/Linux:** 
```bash
./run_unix.sh
```

### Step 4: Use It!

1. Look for the 🧠 icon in the bottom-left corner
2. Go about your normal work
3. When you forget what you were doing, click the icon
4. See your recent activity and any important info (OTPs, emails, etc.)

## That's It!

The app runs silently in the background. Click the brain icon whenever you need to remember what you were doing.

## Tips

- First launch takes ~30 seconds (loading OCR models)
- Context updates every 10 seconds
- Key info (OTPs, codes) is saved for 5 minutes
- Click anywhere outside the panel to close it
